<?php 
$url = "https://www.instarem.com/api/v1/public/transaction/computed-value?source_currency=USD&destination_currency=INR&instarem_bank_account_id=58&source_amount=1000&country_code=US";
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);

$response = curl_exec($ch);
curl_close($ch);
$data = json_decode($response, true);
?>